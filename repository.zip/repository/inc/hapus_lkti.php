<?php
include 'config-konek.php';
session_start();
$id =$_GET["id"];
if (@$_SESSION["user"] == 'alekpedia') {
	mysqli_query($db, "DELETE FROM lkti WHERE id_lkti='$id'");
	header("location:../?p=lkti");
}
else{
	header("location:./?p=beranda");
}
?>