<?php
include 'config-konek.php';
session_start();
$id =$_GET["id"];
if (@$_SESSION["user"] == 'alekpedia') {
	mysqli_query($db, "DELETE FROM essai WHERE id_essai='$id'");
	header("location:../?p=essai");
}
else{
	header("location:./?p=beranda");
}
?>