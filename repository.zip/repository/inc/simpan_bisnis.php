n<?php
$db = mysqli_connect("localhost","root","","forum");
$url = "http://localhost/forum";
?>


<?php 
$judul = $_POST['judul'];
$url = $_POST['url'];
$pemilik = $_POST['pemilik'];

$query= "INSERT INTO bisnis_it VALUES('','$judul','$url','$pemilik','')";

mysqli_query($db,$query);

header("location:../?p=bisnis_it");
?>