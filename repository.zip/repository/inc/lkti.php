
<?php
if (@$_SESSION["user"])

 {
?>

<?php
include "config-konek.php"; 
$query= "SELECT * FROM lkti";
$hasil= mysqli_query($db,$query);
 ?>
<title>Contoh Karya LKTI - <?php echo $data2["nama_user"];?> | Repository Fasco Unsri</title>
<div id="page-inner">
<div class="panel-group">
	<div class="panel panel-info">
		<div class="panel-heading">
			<h3> Daftar LKTI :</h3>
		</div>
		<div class="panel-body">
			<table class='table'>
				<thead>
				<th>No</th>
				<th>Judul Karya</th>
				<th>Pemilik</th>
				<th>File</th>
				<?php
				if (@$data2["level_user"] == '1') {
				echo "<th>Hapus</th>";
				}
				?>
				</thead>
				<tbody>
				<?php
				$no10 = 1;
				while ($data1 = mysqli_fetch_array($hasil)) {
				?>
				<tr>
					<td><?php echo $no10;?></td>
					<td><?php echo $data1["judul"];?></td>
					<td><?php echo $data1["pemilik"];?></td>
					<td><a href="http://<?php echo $data1["url"];?>">Buka</a></td>
					<?php

					
					if (@$data2["level_user"] == '1') {
					?>
						
						<td><a class='btn btn-success' href='./?p=tambah_lkti'>Tambah LKTI</a>
							<a class='btn btn-danger' onclick="return confirm('Apakah Kamu Ingin Menghapus Karya?')" href='./inc/hapus_lkti.php?id=<?php echo $data1["id_lkti"];?>'>Hapus</a></td>
					<?php
					}
					?>
				</tr>
				<?php
				$no10++;
				}
				?>
				</tbody>
			</table>
		</div>
		<div class="panel-footer">
			
		</div>
	</div>
</div>
            </div>
<?php
}
else{
?>
<title>Contoh Karya LKTI - Repository Fasco</title>
<div id="page-inner">
<div class="panel-group">
	<div class="panel panel-info">
		<div class="panel-heading">
			<h3><b><?php $totaldaftarpengguna = mysqli_num_rows($query1); echo $totaldaftarpengguna;?></b> Pengguna Terdaftar :</h3>
		</div>
		<div class="panel-body">
			<table class='table'>
				<thead>
				<th>No</th>
				<th>Judul Karya</th>
				<th>Pemilik</th>
				<th>File</th>
				
				</thead>
				<tbody>
				<?php
				$no10 = 1;
				while ($data1 = mysqli_fetch_array($hasil)) {
				?>
				<tr>
					<td><?php echo $no10;?></td>
					<td><a href="./?p=user&user=<?php echo $data1["user_user"];?>"><?php echo $data1["nama_user"];?></a></td>
					<td>@<?php echo $data1["user_user"];?></td>
					<?php
					if ($data1["status_user"] == 'Online') {
					?>
					<td><a href='#' class="btn btn-success">Online</a></td>
					<?php
					}
					elseif ($data1["status_user"] == "Offline") {
					?>
					<td><a href='#' class="btn btn-default">Offline</a></td>
					<?php
					}
					?>
					</tr>
				<?php
				$no10++;
				}
				?>
				</tbody>
			</table>
		</div>
		<div class="panel-footer">
			
		</div>
	</div>
</div>
            </div>
<?php
}
?>
