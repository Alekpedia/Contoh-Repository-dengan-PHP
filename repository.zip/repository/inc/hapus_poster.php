<?php
include 'config-konek.php';
session_start();
$id =$_GET["id"];
if (@$_SESSION["user"] == 'alekpedia') {
	mysqli_query($db, "DELETE FROM poster WHERE id_poster='$id'");
	header("location:../?p=poster");
}
else{
	header("location:./?p=beranda");
}
?>