<?php
include 'config-konek.php';
session_start();
$id =$_GET["id"];
if (@$_SESSION["user"] == 'alekpedia') {
	mysqli_query($db, "DELETE FROM bisnis_it WHERE id_bisnis='$id'");
	header("location:../?p=bisnis_it");
}
else{
	header("location:./?p=beranda");
}
?>