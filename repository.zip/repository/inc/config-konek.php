<?php
$db = mysqli_connect("localhost","root","","forum");
$url = "http://localhost/forum";
?>
