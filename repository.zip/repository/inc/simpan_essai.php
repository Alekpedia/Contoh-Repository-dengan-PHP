<?php
include "config-konek.php"; 
?>


<?php 
$judul = $_POST['judul'];
$url = $_POST['url'];
$pemilik = $_POST['pemilik'];

$query= "INSERT INTO essai VALUES('','$judul','$url','$pemilik','')";

mysqli_query($db,$query);

header("location:../?p=essai");
?>