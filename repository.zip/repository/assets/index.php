<?php
header("location:../error");
?>